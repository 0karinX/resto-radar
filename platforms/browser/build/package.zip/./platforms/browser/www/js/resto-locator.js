'use strict';

var restoLocator = function(){

	// default constants
	var DEF_SEARCH_RAD 	= 250, 	// default search radius is 250m
		ZOMATO_API_KEY	= '28cc008e99b959e1c17ee8e2f90ff9f5',
		ZOMATO_API_URL	= {		// collection of zomato URLs.
			ULTIMATE_SEARCH : 'https://developers.zomato.com/api/v2.1/search'
		},
		SCAN_RESULT_PAGE_ID = "#scan-results";




	function getListOfNearbyPlacesByGeolocation() {

        // by default implementation, this will send an ajax request to zomato.
        console.log('GET FROM zomato');
		sendAjaxToPlacesStore();
    }

    function getListOfPlacesByCoords() {
        console.log('GET PLACES BY COORDS WITHIN -> ' + DEF_SEARCH_RAD);
    }

    function sendAjaxToPlacesStore(){

    	$.ajax({
		        type: "GET",
		        url: ZOMATO_API_URL.ULTIMATE_SEARCH + '?' + $.param({
		           lat:  	14.5176,
		           lon:  	121.0509,
		           radius: 	DEF_SEARCH_RAD
		        }),
		        contentType: "application/json",
		        headers: {
		        	'user-key' : ZOMATO_API_KEY
		        },
		        dataType: "json"
			})
			.done(function(data) {
    			console.log('AJAX completed');
    			showRestoScanResults(SCAN_RESULT_PAGE_ID);
    		})
	    	.fail(function() {

	    		// display error page here.
	    		console.log('AJAX FAILED');
	    	});
    }

    function showRestoScanResults(resultScanPageID){

    	console.log($(':mobile-pagecontainer').pagecontainer);
		$(':mobile-pagecontainer').pagecontainer('change', 'scan-results.html', {
		        transition: 'flip',
		        changeHash: false,
		        reverse: true,
		        showLoadMsg: true
		    });
    }

    return {

    	getListOfNearbyPlacesByGeolocation 	: getListOfNearbyPlacesByGeolocation,
    	getListOfPlacesByCoords 			: getListOfPlacesByCoords
    }
};